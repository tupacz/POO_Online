﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace POO_1_Parcial_Zuleta_Tupac
{
    public class VistaTorneo
    {
        public VistaTorneo(List<Torneo> torneos)
        {
            listTorneos.Clear();
            listTorneos = torneos;
        }

        public VistaTorneo(Torneo torneo)
        {
            Codigo = torneo.Codigo;
            Nombre = torneo.Nombre;
            FechaInicial = torneo.FechaInicial;
            Finalizado = torneo.Finalizado.Equals(true) ? "Sí" : "No";
            Costo = "$" + torneo.Costo;
            TorneoOriginal = torneo;
        }

        public List<VistaTorneo> ReturnVistaTorneos()
        {
            List<VistaTorneo> vt = new List<VistaTorneo>();
            foreach (var torneo in listTorneos)
            {
                vt.Add(new VistaTorneo(torneo));
            }
            return vt;
        }

        public Torneo ReturnTorneoOriginal()
        {
            return TorneoOriginal;
        }

        public List<Torneo> listTorneos = new List<Torneo>();
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaInicial { get; set; }
        public string Finalizado { get; set; }
        public string Costo { get; set; }
        private Torneo TorneoOriginal { get; set; }
    }
}
