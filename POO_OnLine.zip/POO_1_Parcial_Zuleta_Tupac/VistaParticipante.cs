﻿using System.Collections.Generic;

namespace POO_1_Parcial_Zuleta_Tupac
{
    internal class VistaParticipante
    {
        #region constructores
        public VistaParticipante(List<Participante> participantes)
        {
            listParticipantes.Clear();
            listParticipantes = participantes;
        }

        public VistaParticipante(Participante participante)
        {
            DNI = ""+participante.Dni+"";
            Nombre = participante.Nombre;
            Apellido = participante.Apellido;
            TipoParticipante = participante.EsSocio ? "SO" : "NS";
            ParticipanteOriginal = participante;
        }
        #endregion

        #region metodos
        public List<VistaParticipante> ReturnVistaParticipante()
        {
            List<VistaParticipante> vp = new List<VistaParticipante>();
            foreach (var participante in listParticipantes)
            {
                vp.Add(new VistaParticipante(participante));
            }
            return vp;
        }

        public Participante ReturnParticipanteOriginal()
        {
            return ParticipanteOriginal;
        }
        #endregion

        #region propiedades
        public List<Participante> listParticipantes = new List<Participante>();
        public string DNI { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string TipoParticipante { get; set; }

        private Participante ParticipanteOriginal { get; set; }
        #endregion
    }
}
