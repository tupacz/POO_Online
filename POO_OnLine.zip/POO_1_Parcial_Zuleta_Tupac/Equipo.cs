﻿using System;
using System.Collections.Generic;
using System.Linq;
using static POO_1_Parcial_Zuleta_Tupac.Form1;

namespace POO_1_Parcial_Zuleta_Tupac
{
    public class Equipo
    {
        public Equipo() {
            Participantes = new List<Participante>();
        }

        public Equipo(string codigo, string nombre)
        {
            Codigo = codigo;
            Nombre = nombre;
            Participantes = new List<Participante>();
        }

        public string Codigo { get; set; }
        public string Nombre { get; set; }
        
        //Un equipo está en un solo torneo
        public Torneo Torneo { get; set; }
        internal void AsignarTorneo(Torneo t)
        {
            Torneo = t;
            System.Console.WriteLine("Se asigna el torneo " + t.Codigo + " " + t.Nombre + " al equipo " + Codigo);
        }

        // Un equipo puede tener varios participantes. Hacemos métodos para contar, borrar y agregar
        private List<Participante> Participantes;
        public List<Participante> ListParticipantes() { return Participantes; }
        public int GetParticipantesCount()
        {
            return Participantes.Count();
        }
        public void AsignaParticipante(Participante nuevoParticipante) { Participantes.Add(nuevoParticipante); }
        public void BorraParticipante(Participante bParticipante) { Participantes.Remove(bParticipante); }

        internal List<Participante> ListParticipantesSocios()
        {
            List<Participante> _participantes = new List<Participante>();

            foreach (var item in ListParticipantes())
            {
                if (item.EsSocio)
                {
                    _participantes.Add(item);
                }
            }

            return _participantes;
        }

        internal List<Participante> ListParticipantesNoSocios()
        {
            List<Participante> _participantes = new List<Participante>();

            foreach (var item in ListParticipantes())
            {
                if (item.EsSocio == false)
                {
                    _participantes.Add(item);
                }
            }

            return _participantes;
        }
    }
}
