﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace POO_1_Parcial_Zuleta_Tupac
{
    public class Participante
    {
        public Participante() {
        }

        public Participante(int dni, string nombre, string apellido, bool esSocio)
        {
            Dni = dni;
            Nombre = nombre;
            Apellido = apellido;
            this.EsSocio = esSocio;
        }

        public int Dni { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public Boolean EsSocio { get; set; }
        
        // Un participante está en un solo equipo
        public Equipo Equipo { get; set; }
        internal void AsignarEquipo(Equipo e)
        {
            Equipo = e;
        }

        ~Participante() { Equipo = null; }
    }
}
