﻿namespace POO_1_Parcial_Zuleta_Tupac
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridTorneo = new System.Windows.Forms.DataGridView();
            this.btnAltaTorneo = new System.Windows.Forms.Button();
            this.btnBajaTorneo = new System.Windows.Forms.Button();
            this.btnModificarTorneo = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbEquiposdelTorneo = new System.Windows.Forms.RadioButton();
            this.rbTodoEquipo = new System.Windows.Forms.RadioButton();
            this.dataGridEquipos = new System.Windows.Forms.DataGridView();
            this.BtnModificarEquipos = new System.Windows.Forms.Button();
            this.BtnAltaEquipos = new System.Windows.Forms.Button();
            this.BtnBajaEquipos = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbParticipantesEquipos = new System.Windows.Forms.RadioButton();
            this.dataGridParticipantes = new System.Windows.Forms.DataGridView();
            this.rbTodoParticipante = new System.Windows.Forms.RadioButton();
            this.btnModificarParticipante = new System.Windows.Forms.Button();
            this.btnAltaParticipante = new System.Windows.Forms.Button();
            this.btnBajaParticipante = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridDeportes = new System.Windows.Forms.DataGridView();
            this.btnModificarDeporte = new System.Windows.Forms.Button();
            this.btnAltaDeporte = new System.Windows.Forms.Button();
            this.btnBajaDeporte = new System.Windows.Forms.Button();
            this.btnAsignarEquipo = new System.Windows.Forms.Button();
            this.btnQuitarEquipoAsignado = new System.Windows.Forms.Button();
            this.btnQuitarParticipante = new System.Windows.Forms.Button();
            this.btnAsignarParticipante = new System.Windows.Forms.Button();
            this.btnQuitarTorneoAsignado = new System.Windows.Forms.Button();
            this.btnAsignarTorneo = new System.Windows.Forms.Button();
            this.dataGridTorneosFinalizados = new System.Windows.Forms.DataGridView();
            this.dataGridTorneosNoFinalizados = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRecaudacionTotal = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneo)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEquipos)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridParticipantes)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDeportes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneosFinalizados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneosNoFinalizados)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridTorneo
            // 
            this.dataGridTorneo.AllowUserToAddRows = false;
            this.dataGridTorneo.AllowUserToDeleteRows = false;
            this.dataGridTorneo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTorneo.Location = new System.Drawing.Point(6, 21);
            this.dataGridTorneo.MultiSelect = false;
            this.dataGridTorneo.Name = "dataGridTorneo";
            this.dataGridTorneo.ReadOnly = true;
            this.dataGridTorneo.RowHeadersWidth = 51;
            this.dataGridTorneo.RowTemplate.Height = 24;
            this.dataGridTorneo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridTorneo.Size = new System.Drawing.Size(345, 150);
            this.dataGridTorneo.TabIndex = 0;
            this.dataGridTorneo.SelectionChanged += new System.EventHandler(this.DataGridTorneo_SelectionChanged);
            // 
            // btnAltaTorneo
            // 
            this.btnAltaTorneo.Location = new System.Drawing.Point(6, 177);
            this.btnAltaTorneo.Name = "btnAltaTorneo";
            this.btnAltaTorneo.Size = new System.Drawing.Size(75, 23);
            this.btnAltaTorneo.TabIndex = 1;
            this.btnAltaTorneo.Text = "Alta";
            this.btnAltaTorneo.UseVisualStyleBackColor = true;
            this.btnAltaTorneo.Click += new System.EventHandler(this.BtnAlta_Click);
            // 
            // btnBajaTorneo
            // 
            this.btnBajaTorneo.Location = new System.Drawing.Point(87, 177);
            this.btnBajaTorneo.Name = "btnBajaTorneo";
            this.btnBajaTorneo.Size = new System.Drawing.Size(75, 23);
            this.btnBajaTorneo.TabIndex = 2;
            this.btnBajaTorneo.Text = "Baja";
            this.btnBajaTorneo.UseVisualStyleBackColor = true;
            this.btnBajaTorneo.Click += new System.EventHandler(this.BtnBajaTorneo_Click);
            // 
            // btnModificarTorneo
            // 
            this.btnModificarTorneo.Location = new System.Drawing.Point(168, 177);
            this.btnModificarTorneo.Name = "btnModificarTorneo";
            this.btnModificarTorneo.Size = new System.Drawing.Size(75, 23);
            this.btnModificarTorneo.TabIndex = 3;
            this.btnModificarTorneo.Text = "Modificar";
            this.btnModificarTorneo.UseVisualStyleBackColor = true;
            this.btnModificarTorneo.Click += new System.EventHandler(this.BtnModificarTorneo_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridTorneo);
            this.groupBox1.Controls.Add(this.btnModificarTorneo);
            this.groupBox1.Controls.Add(this.btnAltaTorneo);
            this.groupBox1.Controls.Add(this.btnBajaTorneo);
            this.groupBox1.Location = new System.Drawing.Point(350, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(359, 210);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TORNEOS";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbEquiposdelTorneo);
            this.groupBox2.Controls.Add(this.rbTodoEquipo);
            this.groupBox2.Controls.Add(this.dataGridEquipos);
            this.groupBox2.Controls.Add(this.BtnModificarEquipos);
            this.groupBox2.Controls.Add(this.BtnAltaEquipos);
            this.groupBox2.Controls.Add(this.BtnBajaEquipos);
            this.groupBox2.Location = new System.Drawing.Point(796, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(251, 264);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "EQUIPOS";
            // 
            // rbEquiposdelTorneo
            // 
            this.rbEquiposdelTorneo.AutoSize = true;
            this.rbEquiposdelTorneo.Location = new System.Drawing.Point(6, 233);
            this.rbEquiposdelTorneo.Name = "rbEquiposdelTorneo";
            this.rbEquiposdelTorneo.Size = new System.Drawing.Size(148, 21);
            this.rbEquiposdelTorneo.TabIndex = 16;
            this.rbEquiposdelTorneo.Text = "Equipos del torneo";
            this.rbEquiposdelTorneo.UseVisualStyleBackColor = true;
            // 
            // rbTodoEquipo
            // 
            this.rbTodoEquipo.AutoSize = true;
            this.rbTodoEquipo.Checked = true;
            this.rbTodoEquipo.Location = new System.Drawing.Point(6, 206);
            this.rbTodoEquipo.Name = "rbTodoEquipo";
            this.rbTodoEquipo.Size = new System.Drawing.Size(145, 21);
            this.rbTodoEquipo.TabIndex = 15;
            this.rbTodoEquipo.TabStop = true;
            this.rbTodoEquipo.Text = "Todos los equipos";
            this.rbTodoEquipo.UseVisualStyleBackColor = true;
            this.rbTodoEquipo.CheckedChanged += new System.EventHandler(this.RbTodoEquipo_CheckedChanged);
            // 
            // dataGridEquipos
            // 
            this.dataGridEquipos.AllowUserToAddRows = false;
            this.dataGridEquipos.AllowUserToDeleteRows = false;
            this.dataGridEquipos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridEquipos.Location = new System.Drawing.Point(6, 21);
            this.dataGridEquipos.MultiSelect = false;
            this.dataGridEquipos.Name = "dataGridEquipos";
            this.dataGridEquipos.ReadOnly = true;
            this.dataGridEquipos.RowHeadersWidth = 51;
            this.dataGridEquipos.RowTemplate.Height = 24;
            this.dataGridEquipos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridEquipos.Size = new System.Drawing.Size(237, 150);
            this.dataGridEquipos.TabIndex = 0;
            this.dataGridEquipos.SelectionChanged += new System.EventHandler(this.DataGridEquipos_SelectionChanged);
            // 
            // BtnModificarEquipos
            // 
            this.BtnModificarEquipos.Location = new System.Drawing.Point(168, 177);
            this.BtnModificarEquipos.Name = "BtnModificarEquipos";
            this.BtnModificarEquipos.Size = new System.Drawing.Size(75, 23);
            this.BtnModificarEquipos.TabIndex = 3;
            this.BtnModificarEquipos.Text = "Modificar";
            this.BtnModificarEquipos.UseVisualStyleBackColor = true;
            this.BtnModificarEquipos.Click += new System.EventHandler(this.BtnModificarEquipos_Click);
            // 
            // BtnAltaEquipos
            // 
            this.BtnAltaEquipos.Location = new System.Drawing.Point(6, 177);
            this.BtnAltaEquipos.Name = "BtnAltaEquipos";
            this.BtnAltaEquipos.Size = new System.Drawing.Size(75, 23);
            this.BtnAltaEquipos.TabIndex = 1;
            this.BtnAltaEquipos.Text = "Alta";
            this.BtnAltaEquipos.UseVisualStyleBackColor = true;
            this.BtnAltaEquipos.Click += new System.EventHandler(this.BtnAltaEquipos_Click);
            // 
            // BtnBajaEquipos
            // 
            this.BtnBajaEquipos.Location = new System.Drawing.Point(87, 177);
            this.BtnBajaEquipos.Name = "BtnBajaEquipos";
            this.BtnBajaEquipos.Size = new System.Drawing.Size(75, 23);
            this.BtnBajaEquipos.TabIndex = 2;
            this.BtnBajaEquipos.Text = "Baja";
            this.BtnBajaEquipos.UseVisualStyleBackColor = true;
            this.BtnBajaEquipos.Click += new System.EventHandler(this.BtnBajaEquipos_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbParticipantesEquipos);
            this.groupBox3.Controls.Add(this.dataGridParticipantes);
            this.groupBox3.Controls.Add(this.rbTodoParticipante);
            this.groupBox3.Controls.Add(this.btnModificarParticipante);
            this.groupBox3.Controls.Add(this.btnAltaParticipante);
            this.groupBox3.Controls.Add(this.btnBajaParticipante);
            this.groupBox3.Location = new System.Drawing.Point(1150, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(359, 264);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "PARTICIPANTES";
            // 
            // rbParticipantesEquipos
            // 
            this.rbParticipantesEquipos.AutoSize = true;
            this.rbParticipantesEquipos.Location = new System.Drawing.Point(6, 233);
            this.rbParticipantesEquipos.Name = "rbParticipantesEquipos";
            this.rbParticipantesEquipos.Size = new System.Drawing.Size(181, 21);
            this.rbParticipantesEquipos.TabIndex = 18;
            this.rbParticipantesEquipos.Text = "Participantes del equipo";
            this.rbParticipantesEquipos.UseVisualStyleBackColor = true;
            this.rbParticipantesEquipos.CheckedChanged += new System.EventHandler(this.RbParticipantesEquipos_CheckedChanged);
            // 
            // dataGridParticipantes
            // 
            this.dataGridParticipantes.AllowUserToAddRows = false;
            this.dataGridParticipantes.AllowUserToDeleteRows = false;
            this.dataGridParticipantes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridParticipantes.Location = new System.Drawing.Point(6, 21);
            this.dataGridParticipantes.MultiSelect = false;
            this.dataGridParticipantes.Name = "dataGridParticipantes";
            this.dataGridParticipantes.ReadOnly = true;
            this.dataGridParticipantes.RowHeadersWidth = 51;
            this.dataGridParticipantes.RowTemplate.Height = 24;
            this.dataGridParticipantes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridParticipantes.Size = new System.Drawing.Size(345, 150);
            this.dataGridParticipantes.TabIndex = 0;
            this.dataGridParticipantes.SelectionChanged += new System.EventHandler(this.DataGridParticipantes_SelectionChanged);
            // 
            // rbTodoParticipante
            // 
            this.rbTodoParticipante.AutoSize = true;
            this.rbTodoParticipante.Checked = true;
            this.rbTodoParticipante.Location = new System.Drawing.Point(6, 206);
            this.rbTodoParticipante.Name = "rbTodoParticipante";
            this.rbTodoParticipante.Size = new System.Drawing.Size(176, 21);
            this.rbTodoParticipante.TabIndex = 17;
            this.rbTodoParticipante.TabStop = true;
            this.rbTodoParticipante.Text = "Todos los participantes";
            this.rbTodoParticipante.UseVisualStyleBackColor = true;
            // 
            // btnModificarParticipante
            // 
            this.btnModificarParticipante.Location = new System.Drawing.Point(168, 177);
            this.btnModificarParticipante.Name = "btnModificarParticipante";
            this.btnModificarParticipante.Size = new System.Drawing.Size(75, 23);
            this.btnModificarParticipante.TabIndex = 3;
            this.btnModificarParticipante.Text = "Modificar";
            this.btnModificarParticipante.UseVisualStyleBackColor = true;
            this.btnModificarParticipante.Click += new System.EventHandler(this.BtnModificarParticipante_Click);
            // 
            // btnAltaParticipante
            // 
            this.btnAltaParticipante.Location = new System.Drawing.Point(6, 177);
            this.btnAltaParticipante.Name = "btnAltaParticipante";
            this.btnAltaParticipante.Size = new System.Drawing.Size(75, 23);
            this.btnAltaParticipante.TabIndex = 1;
            this.btnAltaParticipante.Text = "Alta";
            this.btnAltaParticipante.UseVisualStyleBackColor = true;
            this.btnAltaParticipante.Click += new System.EventHandler(this.BtnAltaParticipantes_Click);
            // 
            // btnBajaParticipante
            // 
            this.btnBajaParticipante.Location = new System.Drawing.Point(87, 177);
            this.btnBajaParticipante.Name = "btnBajaParticipante";
            this.btnBajaParticipante.Size = new System.Drawing.Size(75, 23);
            this.btnBajaParticipante.TabIndex = 2;
            this.btnBajaParticipante.Text = "Baja";
            this.btnBajaParticipante.UseVisualStyleBackColor = true;
            this.btnBajaParticipante.Click += new System.EventHandler(this.BtnBajaParticipante_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridDeportes);
            this.groupBox4.Controls.Add(this.btnModificarDeporte);
            this.groupBox4.Controls.Add(this.btnAltaDeporte);
            this.groupBox4.Controls.Add(this.btnBajaDeporte);
            this.groupBox4.Location = new System.Drawing.Point(12, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(251, 210);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "DEPORTES";
            // 
            // dataGridDeportes
            // 
            this.dataGridDeportes.AllowUserToAddRows = false;
            this.dataGridDeportes.AllowUserToDeleteRows = false;
            this.dataGridDeportes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridDeportes.Location = new System.Drawing.Point(6, 21);
            this.dataGridDeportes.MultiSelect = false;
            this.dataGridDeportes.Name = "dataGridDeportes";
            this.dataGridDeportes.ReadOnly = true;
            this.dataGridDeportes.RowHeadersWidth = 51;
            this.dataGridDeportes.RowTemplate.Height = 24;
            this.dataGridDeportes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridDeportes.Size = new System.Drawing.Size(240, 150);
            this.dataGridDeportes.TabIndex = 15;
            this.dataGridDeportes.SelectionChanged += new System.EventHandler(this.DataGridDeportes_SelectionChanged);
            // 
            // btnModificarDeporte
            // 
            this.btnModificarDeporte.Location = new System.Drawing.Point(168, 177);
            this.btnModificarDeporte.Name = "btnModificarDeporte";
            this.btnModificarDeporte.Size = new System.Drawing.Size(75, 23);
            this.btnModificarDeporte.TabIndex = 3;
            this.btnModificarDeporte.Text = "Modificar";
            this.btnModificarDeporte.UseVisualStyleBackColor = true;
            this.btnModificarDeporte.Click += new System.EventHandler(this.BtnModificarDeporte_Click);
            // 
            // btnAltaDeporte
            // 
            this.btnAltaDeporte.Location = new System.Drawing.Point(6, 177);
            this.btnAltaDeporte.Name = "btnAltaDeporte";
            this.btnAltaDeporte.Size = new System.Drawing.Size(75, 23);
            this.btnAltaDeporte.TabIndex = 1;
            this.btnAltaDeporte.Text = "Alta";
            this.btnAltaDeporte.UseVisualStyleBackColor = true;
            this.btnAltaDeporte.Click += new System.EventHandler(this.BtnAltaDeporte_Click);
            // 
            // btnBajaDeporte
            // 
            this.btnBajaDeporte.Location = new System.Drawing.Point(87, 177);
            this.btnBajaDeporte.Name = "btnBajaDeporte";
            this.btnBajaDeporte.Size = new System.Drawing.Size(75, 23);
            this.btnBajaDeporte.TabIndex = 2;
            this.btnBajaDeporte.Text = "Baja";
            this.btnBajaDeporte.UseVisualStyleBackColor = true;
            this.btnBajaDeporte.Click += new System.EventHandler(this.BtnBajaDeporte_Click);
            // 
            // btnAsignarEquipo
            // 
            this.btnAsignarEquipo.Location = new System.Drawing.Point(715, 33);
            this.btnAsignarEquipo.Name = "btnAsignarEquipo";
            this.btnAsignarEquipo.Size = new System.Drawing.Size(75, 68);
            this.btnAsignarEquipo.TabIndex = 9;
            this.btnAsignarEquipo.Text = "Asignar Equipo";
            this.btnAsignarEquipo.UseVisualStyleBackColor = true;
            this.btnAsignarEquipo.Click += new System.EventHandler(this.BtnAsignarEquipo_Click);
            // 
            // btnQuitarEquipoAsignado
            // 
            this.btnQuitarEquipoAsignado.Location = new System.Drawing.Point(715, 115);
            this.btnQuitarEquipoAsignado.Name = "btnQuitarEquipoAsignado";
            this.btnQuitarEquipoAsignado.Size = new System.Drawing.Size(75, 68);
            this.btnQuitarEquipoAsignado.TabIndex = 10;
            this.btnQuitarEquipoAsignado.Text = "Quitar equipo asignado";
            this.btnQuitarEquipoAsignado.UseVisualStyleBackColor = true;
            this.btnQuitarEquipoAsignado.Click += new System.EventHandler(this.BtnQuitarEquipoAsignado_Click);
            // 
            // btnQuitarParticipante
            // 
            this.btnQuitarParticipante.Location = new System.Drawing.Point(1053, 115);
            this.btnQuitarParticipante.Name = "btnQuitarParticipante";
            this.btnQuitarParticipante.Size = new System.Drawing.Size(91, 97);
            this.btnQuitarParticipante.TabIndex = 12;
            this.btnQuitarParticipante.Text = "Quitar Participante Asignado";
            this.btnQuitarParticipante.UseVisualStyleBackColor = true;
            this.btnQuitarParticipante.Click += new System.EventHandler(this.BtnQuitarParticipante_Click);
            // 
            // btnAsignarParticipante
            // 
            this.btnAsignarParticipante.Location = new System.Drawing.Point(1053, 33);
            this.btnAsignarParticipante.Name = "btnAsignarParticipante";
            this.btnAsignarParticipante.Size = new System.Drawing.Size(91, 68);
            this.btnAsignarParticipante.TabIndex = 11;
            this.btnAsignarParticipante.Text = "Asignar Participante";
            this.btnAsignarParticipante.UseVisualStyleBackColor = true;
            this.btnAsignarParticipante.Click += new System.EventHandler(this.BtnAsignarParticipante_Click);
            // 
            // btnQuitarTorneoAsignado
            // 
            this.btnQuitarTorneoAsignado.Location = new System.Drawing.Point(269, 115);
            this.btnQuitarTorneoAsignado.Name = "btnQuitarTorneoAsignado";
            this.btnQuitarTorneoAsignado.Size = new System.Drawing.Size(75, 68);
            this.btnQuitarTorneoAsignado.TabIndex = 14;
            this.btnQuitarTorneoAsignado.Text = "Quitar Torneo Asignado";
            this.btnQuitarTorneoAsignado.UseVisualStyleBackColor = true;
            this.btnQuitarTorneoAsignado.Click += new System.EventHandler(this.BtnQuitarTorneoAsignado_Click);
            // 
            // btnAsignarTorneo
            // 
            this.btnAsignarTorneo.Location = new System.Drawing.Point(269, 33);
            this.btnAsignarTorneo.Name = "btnAsignarTorneo";
            this.btnAsignarTorneo.Size = new System.Drawing.Size(75, 68);
            this.btnAsignarTorneo.TabIndex = 13;
            this.btnAsignarTorneo.Text = "Asignar Torneos";
            this.btnAsignarTorneo.UseVisualStyleBackColor = true;
            this.btnAsignarTorneo.Click += new System.EventHandler(this.BtnAsignarTorneo_Click);
            // 
            // dataGridTorneosFinalizados
            // 
            this.dataGridTorneosFinalizados.AllowUserToAddRows = false;
            this.dataGridTorneosFinalizados.AllowUserToDeleteRows = false;
            this.dataGridTorneosFinalizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTorneosFinalizados.Location = new System.Drawing.Point(12, 318);
            this.dataGridTorneosFinalizados.Name = "dataGridTorneosFinalizados";
            this.dataGridTorneosFinalizados.ReadOnly = true;
            this.dataGridTorneosFinalizados.RowHeadersWidth = 51;
            this.dataGridTorneosFinalizados.RowTemplate.Height = 24;
            this.dataGridTorneosFinalizados.Size = new System.Drawing.Size(697, 150);
            this.dataGridTorneosFinalizados.TabIndex = 15;
            // 
            // dataGridTorneosNoFinalizados
            // 
            this.dataGridTorneosNoFinalizados.AllowUserToAddRows = false;
            this.dataGridTorneosNoFinalizados.AllowUserToDeleteRows = false;
            this.dataGridTorneosNoFinalizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTorneosNoFinalizados.Location = new System.Drawing.Point(802, 318);
            this.dataGridTorneosNoFinalizados.Name = "dataGridTorneosNoFinalizados";
            this.dataGridTorneosNoFinalizados.ReadOnly = true;
            this.dataGridTorneosNoFinalizados.RowHeadersWidth = 51;
            this.dataGridTorneosNoFinalizados.RowTemplate.Height = 24;
            this.dataGridTorneosNoFinalizados.Size = new System.Drawing.Size(699, 150);
            this.dataGridTorneosNoFinalizados.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 295);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "DATOS CONSOLIDADOS TORNEOS FINALIZADOS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(799, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(417, 17);
            this.label2.TabIndex = 18;
            this.label2.Text = "DATOS CONSOLIDADOS TORNEOS POR INICIAR Y EN CURSO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 495);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "TOTAL GENERAL";
            // 
            // txtRecaudacionTotal
            // 
            this.txtRecaudacionTotal.Location = new System.Drawing.Point(12, 516);
            this.txtRecaudacionTotal.Name = "txtRecaudacionTotal";
            this.txtRecaudacionTotal.ReadOnly = true;
            this.txtRecaudacionTotal.Size = new System.Drawing.Size(251, 22);
            this.txtRecaudacionTotal.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1524, 588);
            this.Controls.Add(this.txtRecaudacionTotal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridTorneosNoFinalizados);
            this.Controls.Add(this.dataGridTorneosFinalizados);
            this.Controls.Add(this.btnQuitarTorneoAsignado);
            this.Controls.Add(this.btnAsignarTorneo);
            this.Controls.Add(this.btnQuitarParticipante);
            this.Controls.Add(this.btnAsignarParticipante);
            this.Controls.Add(this.btnQuitarEquipoAsignado);
            this.Controls.Add(this.btnAsignarEquipo);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneo)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEquipos)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridParticipantes)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDeportes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneosFinalizados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTorneosNoFinalizados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridTorneo;
        private System.Windows.Forms.Button btnAltaTorneo;
        private System.Windows.Forms.Button btnBajaTorneo;
        private System.Windows.Forms.Button btnModificarTorneo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridEquipos;
        private System.Windows.Forms.Button BtnModificarEquipos;
        private System.Windows.Forms.Button BtnAltaEquipos;
        private System.Windows.Forms.Button BtnBajaEquipos;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridParticipantes;
        private System.Windows.Forms.Button btnModificarParticipante;
        private System.Windows.Forms.Button btnAltaParticipante;
        private System.Windows.Forms.Button btnBajaParticipante;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnModificarDeporte;
        private System.Windows.Forms.Button btnAltaDeporte;
        private System.Windows.Forms.Button btnBajaDeporte;
        private System.Windows.Forms.Button btnAsignarEquipo;
        private System.Windows.Forms.Button btnQuitarEquipoAsignado;
        private System.Windows.Forms.Button btnQuitarParticipante;
        private System.Windows.Forms.Button btnAsignarParticipante;
        private System.Windows.Forms.Button btnQuitarTorneoAsignado;
        private System.Windows.Forms.Button btnAsignarTorneo;
        private System.Windows.Forms.RadioButton rbEquiposdelTorneo;
        private System.Windows.Forms.RadioButton rbTodoEquipo;
        private System.Windows.Forms.RadioButton rbParticipantesEquipos;
        private System.Windows.Forms.RadioButton rbTodoParticipante;
        private System.Windows.Forms.DataGridView dataGridDeportes;
        private System.Windows.Forms.DataGridView dataGridTorneosFinalizados;
        private System.Windows.Forms.DataGridView dataGridTorneosNoFinalizados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRecaudacionTotal;
    }
}

