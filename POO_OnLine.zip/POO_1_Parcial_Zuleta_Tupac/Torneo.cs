﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;

namespace POO_1_Parcial_Zuleta_Tupac
{
    public class Torneo
    {
        public Deporte Deporte { get; set; }
        public List<Equipo> Equipos { get; set; }
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public decimal Costo { get; set; }

        public bool Finalizado
        {
            get
            {
                DateTime Now = DateTime.Now;
                if (FechaFinal > Now)
                {
                    return false;
                }
                return true;
            }
        }

        #region Constructores
        public Torneo(int codigo, string nombre, DateTime fechaInicial, DateTime fechaFinal, decimal costo)
        {
            Codigo = codigo;
            Nombre = nombre;
            FechaInicial = fechaInicial;
            Costo = costo;
            FechaFinal = fechaFinal;
            Equipos = new List<Equipo>();
        }
        public Torneo()
        {
        }
        #endregion

        # region Metodos
        // Se asigna un solo deporte
        internal void AsignaDeporte(Deporte d)
        {
            Deporte = d;
        }

        // Un Torneo puede tener varios equipos
        public List<Equipo> ListEquipos() { return Equipos; }

        public int CountParticipantesTotal() {
            int countParticipantes = 0;
            foreach (var item in ListEquipos())
            {
                countParticipantes += item.ListParticipantes().Count;
            }
            return countParticipantes; 
        }

        private int CountParticipantesSocios()
        {
            int countParticipantes = 0;
            foreach (var item in ListEquipos())
            {
                countParticipantes += item.ListParticipantesSocios().Count;
            }
            return countParticipantes;
        }

        private int CountParticipantesNoSocios()
        {
            int countParticipantes = 0;
            foreach (var item in ListEquipos())
            {
                countParticipantes += item.ListParticipantesNoSocios().Count;
            }
            return countParticipantes;
        }

        public decimal RecaudacionTotal()
        {
            return RecaudacionNoSocios() + RecaudacionSocios();
        }

        public decimal RecaudacionSocios()
        {
            return CountParticipantesSocios() * (decimal)0.8 * Costo;
        }

        public decimal RecaudacionNoSocios()
        {
            return CountParticipantesNoSocios() * Costo;
        }

        public int GetEquiposCount()
        {
            return Equipos.Count();
        }

        public void AsignarEquipo(Equipo nuevoEquipo) { Equipos.Add(nuevoEquipo); }
        public void BorrarEquipo(Equipo bEquipo) { Equipos.Remove(bEquipo); }
        ~Torneo() { Equipos = null; }

        #endregion
    }
}
