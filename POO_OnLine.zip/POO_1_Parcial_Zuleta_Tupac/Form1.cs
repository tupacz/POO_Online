﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace POO_1_Parcial_Zuleta_Tupac
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Iniciamos con un torneo inicial que me sirvió para no cargar un torneo de prueba cada vez que
            // probaba el proyecto
            torneos = CargarTorneosPrueba();
            deportes = new List<Deporte>();
            equipos = new List<Equipo>();
            participantes = new List<Participante>();

            // La vistaTorneo se supone que es siempre idéntica a los items que hay dentro de torneos
            vistaTorneo = new VistaTorneo(torneos);

            // inicializamos datagrids y selecciones por buenas prácticas
            InicializarSelecciones();
            InicializarGrids();
        }
        
        private void InicializarSelecciones()
        {
            dataGridTorneo.DataSource = null;
            torneoSeleccionado = new Torneo();
            
            dataGridDeportes.DataSource = null;
            deporteSeleccionado = new Deporte();

            dataGridEquipos.DataSource = null;
            equipoSeleccionado = new Equipo();

            dataGridParticipantes.DataSource = null;
            participanteSeleccionado = new Participante();
        }
        private void InicializarGrids()
        {
            MostrarDatagridTorneo();
            MostrarDatagridDeporte();
            MostrarDatagridEquipo();
            MostrarDatagridParticipante();
        }

        #region Torneos
        List<Torneo> torneos;
        Torneo torneoSeleccionado;
        VistaTorneo vistaTorneo;

        private void MostrarBotonesTorneo()
        {
            bool setBool = false;
            if (torneos.Count > 0) setBool = true;
            btnBajaTorneo.Enabled = setBool;
            btnModificarTorneo.Enabled = setBool;
        }

        // Cargo un torneo de prueba
        private List<Torneo> CargarTorneosPrueba()
        {
            List<Torneo> torneosPrueba = new List<Torneo>
            {
                new Torneo(1, "Futbol", DateTime.Parse("1/2/2020"), DateTime.Parse("1/12/2020"), (decimal)3.25)
            };
            return torneosPrueba;
        }

        private void BtnAlta_Click(object sender, EventArgs e)
        {
            try
            {
                torneos.Add(new Torneo(
                    int.Parse(Interaction.InputBox("Código: ")),
                    Interaction.InputBox("Nombre del torneo:"),
                    DateTime.Parse(Interaction.InputBox("Fecha de inicio:")),
                    DateTime.Parse(Interaction.InputBox("Fecha de finalización:")),
                    decimal.Parse(Interaction.InputBox("Costo por participante:"))
                    ));
                vistaTorneo = new VistaTorneo(torneos);
                MostrarDatagridTorneo();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // Esta es una manera de hacer un refresh a los controles del datagrid
        private void MostrarDatagridTorneo()
        {
            dataGridTorneo.DataSource = vistaTorneo.ReturnVistaTorneos();
            MostrarBotonesTorneo();
            // dataGridTorneo.ClearSelection();
        }

        private void BtnBajaTorneo_Click(object sender, EventArgs e)
        {
            try
            {
                Torneo _torneo = torneoSeleccionado;
                
                // eliminamos los equipos asignados
                if (_torneo.GetEquiposCount() > 0)
                {
                    foreach (Equipo _e in _torneo.ListEquipos())
                    {
                        _e.AsignarTorneo(null);
                    }
                }

                //luego borramos el puntero de torneo en deporte
                if(_torneo.Deporte != null)
                {
                    _torneo.Deporte.BorraTorneo(_torneo);
                }
                torneos.Remove(_torneo);
                MostrarDatagridTorneo();
                rbTodoParticipante.Checked = true;
                rbEquiposdelTorneo.Checked = false;

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void BtnModificarTorneo_Click(object sender, EventArgs e)
        {
            try
            {
                Torneo _auxTorneo = ((VistaTorneo)dataGridTorneo.SelectedRows[0].DataBoundItem).ReturnTorneoOriginal();
                if (!(_auxTorneo is null))
                {
                    IngresoDatosTorneo(_auxTorneo);
                }
                MostrarDatagridTorneo();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private static void IngresoDatosTorneo(Torneo _auxTorneo)
        {
            _auxTorneo.Codigo = int.Parse(Interaction.InputBox("Código: "));
            _auxTorneo.Nombre = Interaction.InputBox("Nombre del torneo:");
            _auxTorneo.FechaInicial = DateTime.Parse(Interaction.InputBox("Fecha de inicio:"));
            _auxTorneo.FechaFinal = DateTime.Parse(Interaction.InputBox("Fecha de finalización:"));
            _auxTorneo.Costo = decimal.Parse((Interaction.InputBox("Costo por participante:")).Replace(".",","));
        }

        private void DataGridTorneo_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                torneoSeleccionado = ((VistaTorneo)dataGridTorneo.SelectedRows[0].DataBoundItem).ReturnTorneoOriginal();
            }
            catch (Exception) { }
        }

        #endregion

        #region Deporte
        List<Deporte> deportes;
        Deporte deporteSeleccionado;
        private void BtnAltaDeporte_Click(object sender, EventArgs e)
        {
            try
            {
                Deporte _auxDeporte = new Deporte();
                IngresoDatosDeporte(_auxDeporte);
                deportes.Add(_auxDeporte);
                MostrarDatagridDeporte();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            
        }

        private void ActualizarTorneosFinalizados()
        {
            dataGridTorneosFinalizados.DataSource = new List<VistaTorneosFinalizados>();
            dataGridTorneosFinalizados.Refresh();
            if (torneos.Count() > 0)
            {
                List<VistaTorneosFinalizados> vista = new List<VistaTorneosFinalizados>();
                foreach (var item in torneos)
                {
                    if (item.Finalizado)
                    {
                        vista.Add(new VistaTorneosFinalizados(item));
                    }
                }
                dataGridTorneosFinalizados.DataSource = vista;
                dataGridTorneosFinalizados.Refresh();
            }
        }

        private void ActualizarTorneosNoFinalizados()
        {
            dataGridTorneosNoFinalizados.DataSource = new List<VistaTorneosNoFinalizados>();
            dataGridTorneosNoFinalizados.Refresh();
            if (torneos.Count() > 0)
            {
                List<VistaTorneosNoFinalizados> vista = new List<VistaTorneosNoFinalizados>();
                decimal recaudacionTotal = (decimal)0;
                foreach (var item in torneos)
                {
                    if (item.Finalizado == false)
                    {
                        vista.Add(new VistaTorneosNoFinalizados(item));
                    }
                    recaudacionTotal += item.RecaudacionTotal();
                }
                dataGridTorneosNoFinalizados.DataSource = vista;
                dataGridTorneosNoFinalizados.Refresh();
                txtRecaudacionTotal.Text = "$" + string.Format("{0:0.00}", recaudacionTotal);
            }
        }

        private void MostrarDatagridDeporte()
        {
            dataGridDeportes.DataSource = new List<Deporte>();
            dataGridDeportes.Refresh();
            if (deportes.Count() > 0)
            {
                dataGridDeportes.DataSource = deportes;
                dataGridDeportes.Refresh();
            }
            MostrarBotonesDeporte();
            //dataGridDeportes.ClearSelection();
        }

        private void MostrarBotonesDeporte()
        {
            bool setBool = false;
            if (deportes.Count > 0) setBool = true;
            btnBajaDeporte.Enabled = setBool;
            btnModificarDeporte.Enabled = setBool;
        }

        private void DataGridDeportes_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                deporteSeleccionado = (Deporte)dataGridDeportes.SelectedRows[0].DataBoundItem;
            }
            catch (Exception) { }
        }

        private void BtnBajaDeporte_Click(object sender, EventArgs e)
        {
            try
            {
                Deporte _deporte = deporteSeleccionado;
                if (_deporte.GetTorneosCount() > 0) {
                    foreach (Torneo _t in _deporte.ListTorneos()) {
                        _t.AsignaDeporte(null); }
                }
                deportes.Remove(_deporte);
                MostrarDatagridDeporte();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        
        private void BtnModificarDeporte_Click(object sender, EventArgs e)
        {
            try
            {
                Deporte _deporte = deporteSeleccionado;
                if (_deporte != null)
                {
                    IngresoDatosDeporte(_deporte);
                }
                MostrarDatagridDeporte();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void IngresoDatosDeporte(Deporte deporte)
        {
            deporte.Codigo = Interaction.InputBox("Código: ");
            deporte.Nombre = Interaction.InputBox("Nombre del deporte:");
        }

       
        
        #endregion

        # region Equipo
        List<Equipo> equipos;
        Equipo equipoSeleccionado;
        VistaEquipo vistaEquipo;
        private void BtnAltaEquipos_Click(object sender, EventArgs e)
        {
            try
            {
                // Agrego el nuevo Equipo creado
                Equipo _equipo = new Equipo();
                // Este método lo cree porque lo voy a reutilizar
                IngresoDatosEquipo(_equipo);
                equipos.Add(_equipo);
                
                MostrarDatagridEquipo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void IngresoDatosEquipo(Equipo equipo)
        {
            equipo.Codigo = Interaction.InputBox("Código: ");
            equipo.Nombre = Interaction.InputBox("Nombre del equipo:");
        }

        private void MostrarDatagridEquipo()
        {
            List<Equipo> equiposVisibles = new List<Equipo>();

            if (rbTodoEquipo.Checked)
            {
                equiposVisibles = equipos;
            } 
            else {
                if (torneoSeleccionado != null && torneoSeleccionado.ListEquipos().Count > 0)
                {
                    equiposVisibles = torneoSeleccionado.ListEquipos();
                }
            }

            vistaEquipo = new VistaEquipo(equiposVisibles);
            dataGridEquipos.DataSource = vistaEquipo.ReturnVistaEquipo();
            MostrarBotonesEquipo();
        }

        private void MostrarBotonesEquipo()
        {
            bool setBool = false;
            if (dataGridEquipos.RowCount > 0) setBool = true;
            BtnBajaEquipos.Enabled = setBool;
            BtnModificarEquipos.Enabled = setBool;
        }

        // Cada vez que se selecciona una nueva Row
        private void DataGridEquipos_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                equipoSeleccionado = ((VistaEquipo)dataGridEquipos.SelectedRows[0].DataBoundItem).ReturnEquipoOriginal();
                MostrarDatagridParticipante();
            }
            catch (Exception) { }
        }
        private void BtnBajaEquipos_Click(object sender, EventArgs e)
        {
            try
            {
                Equipo _equipo = equipoSeleccionado;
                // si el equipo tiene muchos participantes tenemos que desanexarlos
                if (_equipo.GetParticipantesCount() > 0)
                {
                    foreach (Participante _p in _equipo.ListParticipantes())
                    {
                        _p.AsignarEquipo(null);
                    }
                }
                // Tambien tenemos que desanexar a los torneos
                _equipo.Torneo.BorrarEquipo(_equipo);

                equipos.Remove(_equipo);
                MostrarDatagridEquipo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnModificarEquipos_Click(object sender, EventArgs e)
        {
            try
            {
                Equipo _equipo = equipoSeleccionado;
                if (_equipo != null)
                {
                    IngresoDatosEquipo(_equipo);
                }
                MostrarDatagridEquipo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        #endregion

        # region Participante
        List<Participante> participantes;
        Participante participanteSeleccionado;
        VistaParticipante vistaParticipante;
        private void BtnAltaParticipantes_Click(object sender, EventArgs e)
        {
            try
            {
                // Agrego el nuevo participante creado
                Participante _participante = new Participante();
                // Este método lo cree porque lo voy a reutilizar
                IngresoDatosParticipante(_participante);
                participantes.Add(_participante);
                MostrarDatagridParticipante();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void IngresoDatosParticipante(Participante participante)
        {
            participante.Dni = int.Parse(Interaction.InputBox("DNI: "));
            participante.Nombre = Interaction.InputBox("Nombre del participante:");
            participante.Apellido = Interaction.InputBox("Apellido del participante:");
            string _EsSocio = Interaction.InputBox("Es socio? Si - No");
            if (_EsSocio == "v" || _EsSocio == "V" || _EsSocio == "si" || _EsSocio == "Si" || _EsSocio == "SI")
            {
                participante.EsSocio = true;
            }
            else if (_EsSocio == "f" || _EsSocio == "F" || _EsSocio == "no" || _EsSocio == "No" || _EsSocio == "NO")
            {
                participante.EsSocio = false;
            }
            else
            {
                throw new Exception("No se reconoce el valor ingresado para la pregunta 'Es socio?'. Debe ser Si o No");
            }
        }

        private void MostrarDatagridParticipante()
        {
            List<Participante> participantesVisibles = new List<Participante>();
            if (rbTodoParticipante.Checked)
            {
                participantesVisibles = participantes;
            }
            else
            {
                if (equipoSeleccionado != null && equipoSeleccionado.ListParticipantes().Count > 0)
                {
                    participantesVisibles = equipoSeleccionado.ListParticipantes();
                }
            }

            vistaParticipante = new VistaParticipante(participantesVisibles);
            dataGridParticipantes.DataSource = vistaParticipante.ReturnVistaParticipante();
            MostrarBotonesParticipantes();
        }

        private void MostrarBotonesParticipantes()
        {
            bool setBool = false;
            if (dataGridParticipantes.RowCount > 0) setBool = true;
            btnBajaParticipante.Enabled = setBool;
            btnModificarParticipante.Enabled = setBool;
        }

        private void DataGridParticipantes_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                participanteSeleccionado = ((VistaParticipante)dataGridParticipantes.SelectedRows[0].DataBoundItem).ReturnParticipanteOriginal();
            }
            catch (Exception) { }
        }

        private void BtnBajaParticipante_Click(object sender, EventArgs e)
        {
            try
            {
                Participante _participante = participanteSeleccionado;
                _participante.Equipo.BorraParticipante(_participante);
                participantes.Remove(participanteSeleccionado);
                MostrarDatagridParticipante();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnModificarParticipante_Click(object sender, EventArgs e)
        {
            try
            {
                Participante _participante = participanteSeleccionado;
                if (_participante != null)
                {
                    IngresoDatosParticipante(_participante);
                }
                MostrarDatagridParticipante();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        #endregion

        #region Asignaciones
        private void BtnAsignarTorneo_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridDeportes, dataGridTorneo, deporteSeleccionado, torneoSeleccionado);
                CheckIfTorneoFinalizado(torneoSeleccionado);
                // creamos variables auxiliares
                Deporte _deporte = deporteSeleccionado;
                Torneo _torneo = torneoSeleccionado;
                // asignamos los objetos correspondientes
                _deporte.AsignaTorneo(_torneo);
                _torneo.AsignaDeporte(_deporte);
                // Mostramos las tablas
                MostrarDatagridDeporte();
                MostrarDatagridTorneo();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CheckIfTorneoFinalizado(Torneo torneo)
        {
            if (torneo.Finalizado)
            throw new Exception("El torneo ya finalizó, no se pueden asignar nuevos deportes, ni equipos, ni participantes");
        }

        private void BtnQuitarTorneoAsignado_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridDeportes, dataGridTorneo, deporteSeleccionado, torneoSeleccionado);
                // creamos variables auxiliares
                Deporte _deporte = deporteSeleccionado;
                Torneo _torneo = torneoSeleccionado;
                // asignamos objetos nulos para reemplazar
                _deporte.BorraTorneo(_torneo);
                _torneo.AsignaDeporte(null);
                // Mostramos las tablas
                MostrarDatagridDeporte();
                MostrarDatagridTorneo();

                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ManejoErroresAsignaciones(DataGridView Grid1, DataGridView Grid2, object Seleccion1, object Seleccion2)
        {
            // chequeamos si hay deportes creados
            if (Grid1.Rows.Count <= 0) throw new Exception("No hay " + Seleccion1.GetType().Name + " en la tabla");
            // chequeamos si hay deportes creados
            if (Grid2.Rows.Count <= 0) throw new Exception("No hay " + Seleccion2.GetType().Name + " en la tabla");
            // chequeamos si hay deporte seleccionado
            if (Seleccion1 is null) throw new Exception("No hay  " + Seleccion1.GetType().Name + " seleccionado");
            // chequeamos si hay torneo seleccionado
            if (Seleccion2 is null) throw new Exception("No hay  " + Seleccion2.GetType().Name + " seleccionado");
            
        }

        private void BtnAsignarEquipo_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridTorneo, dataGridEquipos, torneoSeleccionado, equipoSeleccionado);
                CheckIfTorneoFinalizado(torneoSeleccionado);
                // creamos variables auxiliares
                Equipo _equipo = equipoSeleccionado;
                Torneo _torneo = torneoSeleccionado;
                // asignamos los objetos correspondientes
                _equipo.AsignarTorneo(_torneo);
                _torneo.AsignarEquipo(_equipo);
                // Mostramos las tablas
                MostrarDatagridEquipo();
                MostrarDatagridTorneo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnQuitarEquipoAsignado_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridEquipos, dataGridTorneo, torneoSeleccionado, equipoSeleccionado);
                // creamos variables auxiliares
                Equipo _equipo = equipoSeleccionado;
                Torneo _torneo = torneoSeleccionado;
                // asignamos objetos nulos para reemplazar
                _equipo.AsignarTorneo(null);
                _torneo.BorrarEquipo(_equipo);
                // Mostramos las tablas
                MostrarDatagridDeporte();
                MostrarDatagridTorneo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnAsignarParticipante_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridEquipos, dataGridParticipantes, equipoSeleccionado, participanteSeleccionado);
                if (equipoSeleccionado.Torneo != null) CheckIfTorneoFinalizado(equipoSeleccionado.Torneo);
                // creamos variables auxiliares
                Participante _participante = participanteSeleccionado;
                Equipo _equipo = equipoSeleccionado;
                // asignamos los objetos correspondientes
                _participante.AsignarEquipo(_equipo);
                _equipo.AsignaParticipante(_participante);
                // Mostramos las tablas
                MostrarDatagridParticipante();
                MostrarDatagridEquipo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnQuitarParticipante_Click(object sender, EventArgs e)
        {
            try
            {
                ManejoErroresAsignaciones(dataGridEquipos, dataGridParticipantes, equipoSeleccionado, participanteSeleccionado);
                // creamos variables auxiliares
                Equipo _equipo = equipoSeleccionado;
                Participante _participante = participanteSeleccionado;
                // asignamos objetos nulos para reemplazar
                _equipo.BorraParticipante(_participante);
                _participante.AsignarEquipo(null);
                // Mostramos las tablas
                MostrarDatagridDeporte();
                MostrarDatagridTorneo();

                //Actualizamos las vistas consolidadas
                ActualizarTorneosFinalizados();
                ActualizarTorneosNoFinalizados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region checkedChange
        private void RbTodoEquipo_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                MostrarDatagridEquipo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RbParticipantesEquipos_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                MostrarDatagridParticipante();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion
    }
}
