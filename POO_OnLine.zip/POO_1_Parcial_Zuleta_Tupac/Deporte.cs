﻿using System.Collections.Generic;
using System.Linq;

namespace POO_1_Parcial_Zuleta_Tupac
{
    public class Deporte
    {
        private List<Torneo> torneos;
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public List<Torneo> ListTorneos() { return torneos; }

        public Deporte() { torneos = new List<Torneo>(); }
        public Deporte(string codigo, string nombre)
        {
            Codigo = codigo;
            Nombre = nombre;
            torneos = new List<Torneo>();
        }

        public int GetTorneosCount()
        {
            return torneos.Count();
        }

        public void AsignaTorneo(Torneo nuevoTorneo) { torneos.Add(nuevoTorneo); }
        public void BorraTorneo(Torneo bTorneo) { torneos.Remove(bTorneo); }
        ~Deporte() { torneos = null; }  
    }
}
