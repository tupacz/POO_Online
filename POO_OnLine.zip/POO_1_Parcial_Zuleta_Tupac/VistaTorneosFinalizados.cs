﻿using System;

namespace POO_1_Parcial_Zuleta_Tupac
{
    internal class VistaTorneosFinalizados
    {
        #region propiedades
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public int CantidadEquipos { get; set; }
        public int CantidadParticipantes { get; set; }
        public string Deporte { get; set; }
        public string TotalRecaudado { get; set; }
        #endregion

        #region constructores
        public VistaTorneosFinalizados(Torneo torneo)
        {
            try
            {
                if (torneo.Finalizado == false) throw new Exception("El torneo no está finalizado");
                Codigo = torneo.Codigo;
                Nombre = torneo.Nombre;
                CantidadEquipos = torneo.ListEquipos().Count;
                CantidadParticipantes = torneo.CountParticipantesTotal();
                Deporte = torneo.Deporte == null ? "" : torneo.Deporte.Nombre;
                TotalRecaudado = "$" + string.Format("{0:0.00}", torneo.RecaudacionSocios() + torneo.RecaudacionNoSocios());
            }
            catch (Exception)
            {
            }
        }
        #endregion
    }
}
