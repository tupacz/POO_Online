﻿using System.Collections.Generic;

namespace POO_1_Parcial_Zuleta_Tupac
{
    internal class VistaEquipo
    {
        #region constructores
        public VistaEquipo(List<Equipo> equipos)
        {
            listEquipos.Clear();
            listEquipos = equipos;
        }

        public VistaEquipo(Equipo equipo)
        {
            Codigo = equipo.Codigo;
            Nombre = equipo.Nombre;
            EquipoOriginal = equipo;

        }
        #endregion

        #region metodos
        public List<VistaEquipo> ReturnVistaEquipo()
        {
            List<VistaEquipo> vt = new List<VistaEquipo>();
            foreach (var equipo in listEquipos)
            {
                vt.Add(new VistaEquipo(equipo));
            }
            return vt;
        }

        public Equipo ReturnEquipoOriginal()
        {
            return EquipoOriginal;
        }
        #endregion

        #region propiedades
        public List<Equipo> listEquipos = new List<Equipo>();
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        private Equipo EquipoOriginal { get; set; }
        #endregion
    }
}